package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Signup3 extends JFrame implements ActionListener {

    JRadioButton r1, r2, r3, r4;
    JCheckBox c1, c2, c3, c4, c5, c6, c7;
    JButton submit, cancel;
    String formno;

    Signup3(String formno) {
        this.formno = formno;
        setLayout(null);
        setTitle("NEW ACCOUNT FORM - PAGE 3");

        JLabel l1 = new JLabel("Page 3: Account Details");
        l1.setFont(new Font("Raleway", Font.BOLD, 24));
        l1.setBounds(280, 40, 400, 40);
        add(l1);

        JLabel type = new JLabel("Account Type:");
        type.setFont(new Font("Raleway", Font.BOLD, 18));
        type.setBounds(100, 140, 200, 30);
        add(type);

        r1 = new JRadioButton("Savings Account");
        r2 = new JRadioButton("Fixed Deposit Account");
        r3 = new JRadioButton("Current Account");
        r4 = new JRadioButton("Recurring Deposit Account");

        JRadioButton[] radios = {r1, r2, r3, r4};
        int y = 180;
        for (int i = 0; i < radios.length; i++) {
            radios[i].setFont(new Font("Raleway", Font.BOLD, 16)); 
            radios[i].setBackground(new Color(180, 220, 255));     
            radios[i].setBounds((i % 2 == 0 ? 100 : 350), y, 250, 25);
            add(radios[i]);
            if (i % 2 != 0) y += 40;
        }

        ButtonGroup groupaccount = new ButtonGroup();
        groupaccount.add(r1);
        groupaccount.add(r2);
        groupaccount.add(r3);
        groupaccount.add(r4);

        JLabel card = new JLabel("Card Number:");
        card.setFont(new Font("Raleway", Font.BOLD, 18));
        card.setBounds(100, 300, 200, 30);
        add(card);

        JLabel number = new JLabel("XXXX-XXXX-XXXX-0000");
        number.setFont(new Font("Raleway", Font.BOLD, 18));
        number.setBounds(330, 300, 300, 30);
        add(number);

        JLabel pin = new JLabel("PIN:");
        pin.setFont(new Font("Raleway", Font.BOLD, 18));
        pin.setBounds(100, 370, 200, 30);
        add(pin);

        JLabel pnumber = new JLabel("XXXX");
        pnumber.setFont(new Font("Raleway", Font.BOLD, 18));
        pnumber.setBounds(330, 370, 300, 30);
        add(pnumber);

        JLabel service = new JLabel("Services Required:");
        service.setFont(new Font("Raleway", Font.BOLD, 18));
        service.setBounds(100, 440, 300, 30);
        add(service);

        c1 = new JCheckBox("ATM CARD");
        c2 = new JCheckBox("Internet Banking");
        c3 = new JCheckBox("Mobile Banking");
        c4 = new JCheckBox("EMAIL & SMS Alerts");
        c5 = new JCheckBox("Cheque Book");
        c6 = new JCheckBox("E-Statement");
        c7 = new JCheckBox("I hereby declare that the above entered details are correct to the best of my knowledge.");

        JCheckBox[] checks = {c1, c2, c3, c4, c5, c6};
        y = 500;
        for (int i = 0; i < checks.length; i++) {
            checks[i].setFont(new Font("Raleway", Font.BOLD, 15));  
            checks[i].setBackground(new Color(180, 220, 255));
            checks[i].setBounds((i % 2 == 0 ? 100 : 350), y, 200, 30);
            add(checks[i]);
            if (i % 2 != 0) y += 50;
        }

        c7.setFont(new Font("Raleway", Font.BOLD, 13));  
        c7.setBackground(new Color(180, 220, 255));
        c7.setBounds(80, 680, 650, 30);
        add(c7);

        submit = new JButton("Submit");
        styleButtonWithHover(submit, new Color(34, 139, 34), new Color(50, 205, 50));
        submit.setBounds(420, 720, 100, 30);
        submit.addActionListener(this);
        add(submit);

        cancel = new JButton("Cancel");
        styleButtonWithHover(cancel, new Color(178, 34, 34), new Color(220, 20, 60));
        cancel.setBounds(250, 720, 100, 30);
        cancel.addActionListener(this);
        add(cancel);

        getContentPane().setBackground(new Color(180, 220, 255)); 

        setSize(850, 820);
        setLocation(350, 0);
        setVisible(true);
    }

    private void styleButtonWithHover(JButton button, Color normal, Color hover) {
        button.setFont(new Font("Raleway", Font.BOLD, 15));
        button.setBackground(normal);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder());

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(hover);
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(normal);
            }
        });
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == submit) {
            String accountType = null;
            if (r1.isSelected()) accountType = "Savings Account";
            else if (r2.isSelected()) accountType = "Fixed Deposit Account";
            else if (r3.isSelected()) accountType = "Current Account";
            else if (r4.isSelected()) accountType = "Recurring Deposit Account";

            Random random = new Random();
            String cardnumber = "" + Math.abs(random.nextLong() % 90000000L + 5040936000000000L);
            String pinnumber = "" + Math.abs((random.nextLong() % 9000L) + 1000L);

            StringBuilder facility = new StringBuilder();
            if (c1.isSelected()) facility.append("ATM Card, ");
            if (c2.isSelected()) facility.append("Internet Banking, ");
            if (c3.isSelected()) facility.append("Mobile Banking, ");
            if (c4.isSelected()) facility.append("EMAIL & SMS Alerts, ");
            if (c5.isSelected()) facility.append("Cheque Book, ");
            if (c6.isSelected()) facility.append("E-Statement");

            if (facility.toString().endsWith(", ")) {
                facility = new StringBuilder(facility.substring(0, facility.length() - 2));
            }

            if (!c7.isSelected()) {
                JOptionPane.showMessageDialog(null, "You must agree to the declaration before proceeding.");
                return;
            }

            try {
                if (accountType == null) {
                    JOptionPane.showMessageDialog(null, "Account Type is Required");
                } else {
                    Conn conn = new Conn();
                    String query1 = "insert into signUp3 values('" + formno + "', '" + accountType + "',  '" + cardnumber + "', '" + pinnumber + "','" + facility + "')";
                    String query2 = "insert into login values('" + formno + "','" + cardnumber + "', '" + pinnumber + "')";

                    conn.s.executeUpdate(query1);
                    conn.s.executeUpdate(query2);

                    JOptionPane.showMessageDialog(null, "Account Created Successfully\nCard No: " + cardnumber + "\nPIN: " + pinnumber);
                    setVisible(false);
                    new Transaction(pinnumber).setVisible(true);
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        } else if (ae.getSource() == cancel) {
            dispose();
            new Login().setVisible(true);
        }
    }

    public static void main(String args[]) {
        new Signup3("formno");
    }
}

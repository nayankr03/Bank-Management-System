package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {
    
    JButton login, signup, clear;
    JTextField cardField;
    JPasswordField pinField;

    Login() {
        setTitle("Automated Teller Machine");
        setLayout(null);
        
      
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image i2 = i1.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel iconLabel = new JLabel(i3);
        iconLabel.setBounds(30, 30, 80, 80);
        add(iconLabel);
        
       

       
        JLabel atmText = new JLabel("Welcome to ATM");
        atmText.setFont(new Font("Segoe UI", Font.BOLD, 28));
        atmText.setBounds(130, 40, 400, 40);
        add(atmText);

       
        JLabel cardLabel = new JLabel("Card Number");
        cardLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        cardLabel.setBounds(100, 150, 150, 25);
        add(cardLabel);

        cardField = new JTextField();
        cardField.setBounds(250, 150, 250, 30);
        cardField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        cardField.setToolTipText("Enter your 16-digit card number");
        add(cardField);

       
        JLabel pinLabel = new JLabel("PIN");
        pinLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        pinLabel.setBounds(100, 200, 150, 25);
        add(pinLabel);

        pinField = new JPasswordField();
        pinField.setBounds(250, 200, 250, 30);
        pinField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        pinField.setToolTipText("Enter your 4-digit PIN");
        add(pinField);

        
        login = new JButton("SIGN IN");
        login.setBounds(250, 260, 110, 35);
        styleButton(login, new Color(0, 102, 204)); 
        login.addActionListener(this);
        add(login);

        clear = new JButton("CLEAR");
        clear.setBounds(390, 260, 110, 35);
        styleButton(clear, new Color(204, 0, 0));  
        clear.addActionListener(this);
        add(clear);

        signup = new JButton("SIGN UP");
        signup.setBounds(250, 310, 250, 35);
        styleButton(signup, new Color(0, 153, 76));  
        signup.addActionListener(this);
        add(signup);

       
        getContentPane().setBackground(new Color(240, 248, 255));

        setSize(650, 450);
        setLocationRelativeTo(null); 
        setVisible(true);
    }

   
private void styleButton(JButton btn, Color baseColor) {
    btn.setBackground(baseColor);
    btn.setForeground(Color.WHITE);
    btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
    btn.setFocusPainted(false);
    btn.setBorder(BorderFactory.createEmptyBorder());

    Color hoverColor = baseColor.brighter(); 

    btn.addMouseListener(new MouseAdapter() {
        public void mouseEntered(MouseEvent e) {
            btn.setBackground(hoverColor);
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        public void mouseExited(MouseEvent e) {
            btn.setBackground(baseColor);
            btn.setCursor(Cursor.getDefaultCursor());
        }
    });
}


    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == clear) {
            cardField.setText("");
            pinField.setText("");
        } else if (ae.getSource() == login) {
            String cardno = cardField.getText();
            String pin = new String(pinField.getPassword());
            try {
                Conn conn = new Conn();
                String query = "select * from login where cardnumber = '" + cardno + "' and pin = '" + pin + "'";
                ResultSet rs = conn.s.executeQuery(query);
                if (rs.next()) {
                    setVisible(false);
                    new Transaction(pin).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect Card Number or PIN");
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        } else if (ae.getSource() == signup) {
            setVisible(false);
            new SignUpOne().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}

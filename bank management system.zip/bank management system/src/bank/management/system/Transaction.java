package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Transaction extends JFrame implements ActionListener {

    JButton b1, b2, b3, b4, b5, b6, b7;
    String pin;

    Color baseColor = new Color(70, 130, 180);       
    Color hoverColor = new Color(100, 149, 237);     
    Color exitColor = new Color(220, 53, 69);       
    Color exitHover = new Color(200, 35, 51);        

    public Transaction(String pin) {
        this.pin = pin;
        setLayout(null);

        JLabel image;
        try {
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
            Image i2 = i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            image = new JLabel(i3);
        } catch (Exception e) {
            image = new JLabel();
            image.setOpaque(true);
            image.setBackground(new Color(230, 240, 255)); 
        }

        image.setBounds(0, 0, 900, 900);
        add(image);

        JLabel text = new JLabel("Please select your Transaction");
        text.setFont(new Font("Segoe UI", Font.BOLD, 18));
        text.setForeground(Color.WHITE);
        text.setBounds(230, 300, 400, 35);
        image.add(text);

        b1 = createButton("Deposit", 170, 415, baseColor, hoverColor);
        b2 = createButton("Cash Withdraw", 355, 415, baseColor, hoverColor);
        b3 = createButton("Fast Cash", 170, 450, baseColor, hoverColor);
        b4 = createButton("Balance Enquiry", 355, 450, baseColor, hoverColor);
        b5 = createButton("Mini Statement", 170, 485, baseColor, hoverColor);
        b6 = createButton("Pin Change", 355, 485, baseColor, hoverColor);
        b7 = createButton("EXIT", 355, 520, exitColor, exitHover);

        image.add(b1);
        image.add(b2);
        image.add(b3);
        image.add(b4);
        image.add(b5);
        image.add(b6);
        image.add(b7);

        setSize(900, 900);
        setLocation(300, 0);
        setVisible(true);
    }

    private JButton createButton(String text, int x, int y, Color bg, Color hover) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 150, 30);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setBackground(bg);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder());
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(this);

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(hover);
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(bg);
            }
        });

        return button;
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b7) {
            System.exit(0);
        } else if (ae.getSource() == b1) {
            setVisible(false);
            new Deposit(pin).setVisible(true);
        } else if (ae.getSource() == b2) {
            setVisible(false);
            new Withdrawl(pin).setVisible(true);
        } else if (ae.getSource() == b3) {
            setVisible(false);
            new FastCash(pin).setVisible(true);
        } else if (ae.getSource() == b4) {
            setVisible(false);
            new balanceenquiry(pin).setVisible(true);
        } else if (ae.getSource() == b5) {
            setVisible(false);
            new ministatement(pin).setVisible(true);
        } else if (ae.getSource() == b6) {
            setVisible(false);
            new PinChange(pin).setVisible(true);
        }
    }

    public static void main(String[] args) {
        new Transaction("");
    }
}

package bank.management.system;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;

public class SignUpOne extends JFrame implements ActionListener {

    long random;
    JTextField t1, t2, t3, t4, t5, t6, t7, t8;
    JButton next;
    JRadioButton male, female, married, unmarried;
    JDateChooser dateChooser;

    SignUpOne() {

        setTitle("Bank Management System - Sign Up");
        setLayout(null);

        getContentPane().setBackground(new Color(220, 235, 247));

        Random ran = new Random();
        random = Math.abs((ran.nextLong() % 9000L) + 1000L);

        JLabel formno = new JLabel("APPLICATION FORM NO. " + random);
        formno.setFont(new Font("Raleway", Font.BOLD, 30));
        formno.setBounds(180, 20, 700, 40);
        formno.setForeground(new Color(0, 51, 102));
        add(formno);

        JLabel personDetails = new JLabel("Page 1: Personal Details");
        personDetails.setFont(new Font("Arial", Font.PLAIN, 18));
        personDetails.setBounds(290, 70, 400, 30);
        add(personDetails);

        int leftX = 100, labelWidth = 200, fieldX = 300, fieldWidth = 400;
        int y = 120, gap = 50;

        Font labelFont = new Font("Arial", Font.BOLD, 16);
        Font inputFont = new Font("Arial", Font.PLAIN, 16);
        Color labelColor = new Color(0, 51, 102);

        String[] labels = {
            "<html>Name<font color='red'>*</font>:</html>", 
            "<html>Father's Name<font color='red'>*</font>:</html>",
            "<html>Date of Birth<font color='red'>*</font>:</html>",
            "<html>Gender<font color='red'>*</font>:</html>",
            "<html>Email Address<font color='red'>*</font>:</html>",
            "<html>Phone Number<font color='red'>*</font>:</html>",
            "<html>Marital Status<font color='red'>*</font>:</html>",
            "<html>Address<font color='red'>*</font>:</html>",
            "<html>City<font color='red'>*</font>:</html>",
            "<html>State<font color='red'>*</font>:</html>",
            "<html>Pin Code<font color='red'>*</font>:</html>"
        };

        JLabel name = new JLabel(labels[0]); name.setBounds(leftX, y, labelWidth, 30); name.setFont(labelFont); name.setForeground(labelColor); add(name);
        t1 = new JTextField(); t1.setBounds(fieldX, y, fieldWidth, 30); t1.setFont(inputFont); add(t1); y += gap;

        JLabel fname = new JLabel(labels[1]); fname.setBounds(leftX, y, labelWidth, 30); fname.setFont(labelFont); fname.setForeground(labelColor); add(fname);
        t2 = new JTextField(); t2.setBounds(fieldX, y, fieldWidth, 30); t2.setFont(inputFont); add(t2); y += gap;

        JLabel dob = new JLabel(labels[2]); dob.setBounds(leftX, y, labelWidth, 30); dob.setFont(labelFont); dob.setForeground(labelColor); add(dob);
        dateChooser = new JDateChooser(); dateChooser.setBounds(fieldX, y, 200, 30); 
        ((JTextField) dateChooser.getDateEditor().getUiComponent()).setFont(inputFont);
        add(dateChooser); y += gap;

        JLabel gender = new JLabel(labels[3]); gender.setBounds(leftX, y, labelWidth, 30); gender.setFont(labelFont); gender.setForeground(labelColor); add(gender);
        male = new JRadioButton("Male"); female = new JRadioButton("Female");
        male.setBounds(fieldX, y, 100, 30); female.setBounds(fieldX + 120, y, 100, 30);
        male.setBackground(new Color(220, 235, 247)); female.setBackground(new Color(220, 235, 247));
        male.setFont(inputFont); female.setFont(inputFont);
        ButtonGroup genderGroup = new ButtonGroup(); genderGroup.add(male); genderGroup.add(female);
        add(male); add(female); y += gap;

        JLabel email = new JLabel(labels[4]); email.setBounds(leftX, y, labelWidth, 30); email.setFont(labelFont); email.setForeground(labelColor); add(email);
        t3 = new JTextField(); t3.setBounds(fieldX, y, fieldWidth, 30); t3.setFont(inputFont); add(t3); y += gap;

        JLabel phone = new JLabel(labels[5]); phone.setBounds(leftX, y, labelWidth, 30); phone.setFont(labelFont); phone.setForeground(labelColor); add(phone);
        t8 = new JTextField(); t8.setBounds(fieldX, y, fieldWidth, 30); t8.setFont(inputFont); add(t8); y += gap;

        JLabel marry = new JLabel(labels[6]); marry.setBounds(leftX, y, labelWidth, 30); marry.setFont(labelFont); marry.setForeground(labelColor); add(marry);
        married = new JRadioButton("Married"); unmarried = new JRadioButton("Unmarried");
        married.setBounds(fieldX, y, 100, 30); unmarried.setBounds(fieldX + 120, y, 100, 30);
        married.setBackground(new Color(220, 235, 247)); unmarried.setBackground(new Color(220, 235, 247));
        married.setFont(inputFont); unmarried.setFont(inputFont);
        ButtonGroup maritalGroup = new ButtonGroup(); maritalGroup.add(married); maritalGroup.add(unmarried);
        add(married); add(unmarried); y += gap;

        JLabel address = new JLabel(labels[7]); address.setBounds(leftX, y, labelWidth, 30); address.setFont(labelFont); address.setForeground(labelColor); add(address);
        t4 = new JTextField(); t4.setBounds(fieldX, y, fieldWidth, 30); t4.setFont(inputFont); add(t4); y += gap;

        JLabel city = new JLabel(labels[8]); city.setBounds(leftX, y, labelWidth, 30); city.setFont(labelFont); city.setForeground(labelColor); add(city);
        t5 = new JTextField(); t5.setBounds(fieldX, y, fieldWidth, 30); t5.setFont(inputFont); add(t5); y += gap;

        JLabel state = new JLabel(labels[9]); state.setBounds(leftX, y, labelWidth, 30); state.setFont(labelFont); state.setForeground(labelColor); add(state);
        t6 = new JTextField(); t6.setBounds(fieldX, y, fieldWidth, 30); t6.setFont(inputFont); add(t6); y += gap;

        JLabel pincode = new JLabel(labels[10]); pincode.setBounds(leftX, y, labelWidth, 30); pincode.setFont(labelFont); pincode.setForeground(labelColor); add(pincode);
        t7 = new JTextField(); t7.setBounds(fieldX, y, fieldWidth, 30); t7.setFont(inputFont); add(t7); y += gap + 10;

        next = new JButton("Next");
        next.setBounds(fieldX + 320, y, 100, 35);
        next.setBackground(new Color(0, 102, 204));
        next.setForeground(Color.WHITE);
        next.setFocusPainted(false);
        next.setFont(new Font("Arial", Font.BOLD, 16));
        next.addActionListener(this);
        add(next);

      
        setEnterKeyFocus(t1, t2);
        setEnterKeyFocus(t2, ((JTextField) dateChooser.getDateEditor().getUiComponent()));
        setEnterKeyFocus(((JTextField) dateChooser.getDateEditor().getUiComponent()), t3);
        setEnterKeyFocus(t3, t8);
        setEnterKeyFocus(t8, t4);
        setEnterKeyFocus(t4, t5);
        setEnterKeyFocus(t5, t6);
        setEnterKeyFocus(t6, t7);
      
        t7.addActionListener(e -> next.requestFocus());

        setSize(850, y + 120);
        setLocation(350, 10);
        setVisible(true);
    }

    
    private void setEnterKeyFocus(JTextField current, JTextField next) {
        current.addActionListener(e -> next.requestFocus());
    }

    public void actionPerformed(ActionEvent ae) {
        String formno = "" + random;
        String name = t1.getText();
        String fname = t2.getText();
        Date dobDate = dateChooser.getDate();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = male.isSelected() ? "Male" : (female.isSelected() ? "Female" : null);
        String email = t3.getText();
        String phone = t8.getText();
        String marital = married.isSelected() ? "Married" : (unmarried.isSelected() ? "Unmarried" : null);
        String address = t4.getText(), city = t5.getText(), state = t6.getText(), pin = t7.getText();

        try {
            if (name.equals("") || fname.equals("") || dob.equals("") || gender == null ||
                address.equals("") || city.equals("") || state.equals("") || pin.equals("") ||
                (email.equals("") && phone.equals(""))) {
                JOptionPane.showMessageDialog(null, "Please fill all required fields.");
            } 
            else if (dobDate == null) {
                JOptionPane.showMessageDialog(null, "Please select your Date of Birth.");
            } 
            else {
               
                Calendar today = Calendar.getInstance();
                Calendar dobCal = Calendar.getInstance();
                dobCal.setTime(dobDate);

                int age = today.get(Calendar.YEAR) - dobCal.get(Calendar.YEAR);
                if (today.get(Calendar.DAY_OF_YEAR) < dobCal.get(Calendar.DAY_OF_YEAR)) {
                    age--;
                }

                if (age < 18) {
                    JOptionPane.showMessageDialog(null, "Age must be 18 or above.");
                    return;
                }

               
                if (!phone.matches("\\d{10}")) {
                    JOptionPane.showMessageDialog(null, "Phone number must be 10 digits and numeric values.");
                } else if (!pin.matches("\\d{6}")) {
                    JOptionPane.showMessageDialog(null, "Pin code must be 6 digits and numeric values.");
                } else {
                    Conn c = new Conn();
                    String query = "insert into signup values('" + formno + "', '" + name + "', '" + fname + "', '" + dob + "', '" + gender + "', '" + email + "', '" + marital + "', '" + address + "', '" + city + "', '" + pin + "', '" + state + "', '" + phone + "')";
                    c.s.executeUpdate(query);
                    setVisible(false);
                    new SignUp2(formno).setVisible(true);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String args[]) {
        new SignUpOne();
    }
}
